echo Starting work

while ($true) {
  echo "We be working"
  Start-Sleep -s 5
}
